#include<bits/stdc++.h>
#define all(x) (x).begin(),(x).end()
using namespace std;

typedef long long ll;
typedef pair<ll,ll> PII;
const int N = 2e5 + 10;

ll nums[350];

int main(){
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	int T;
	cin >> T;
	while(T--){
		ll n,cnt = 0,idx;
		cin >> n;
		for(int i = 0;i < n;i++){
			cin >> nums[i];
			if(nums[i] & 1){
				cnt++;
				idx = i;
			}
		}
		if(n == 3){
			if(cnt & 1){
				cout << "YES\n";
				cout << "1 2 3\n";
			}
			else cout << "NO\n";
			continue;
		}
		if(cnt == 0) {cout << "NO\n";continue;}
		cout << "YES\n";
		cout << idx + 1 << " ";
		cnt = 0;
		for(int i = 0;cnt < 2 && i < n;i++){
			
		}
	}
	return 0;
}