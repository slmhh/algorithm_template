#include<bits/stdc++.h>
#define all(x) (x).begin(),(x).end()
using namespace std;

typedef long long ll;
typedef pair<ll,ll> PII;
const int N = 1e6 + 10;
ll inf = 0x3f3f3f3f;

ll pre[N],las[N];

int main(){
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	int T;
	cin >> T;
	//T = 1;
	while(T--){
		ll n,q,flag = 0;
		cin >> n >> q;
		set<PII> s;
		string str;
		cin >> str;
		ll idx = 1;
		for(int i = 0;i < str.size();i++){
			if(str[i] == '1') flag = 1;
			if(str[i] == '0' && flag == 1){ idx = i + 1;flag = 0;}
			pre[i] = idx;
		}
		idx--;
		flag = 0;
		for(int i = str.size() - 1;i >= 0;i--){
			if(str[i] == '0') flag = 1;
			if(str[i] == '1' && flag == 1){ idx = i + 1;flag = 0;}
			las[i] = idx;
		}
		while(q--){
			ll l,r;
			cin >> l >> r;
			if(pre[l - 1] == pre[r - 1]) l = 1,r = n + 1;
			else {l = pre[l - 1] ;
				r = max(las[r - 1],r);
			}
			s.insert(PII{l,r});
			cout << "l = " << l << " r = " << r << endl;
		}
		cout << s.size() << "\n";
	}
	return 0;
}