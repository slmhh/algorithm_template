	#include<bits/stdc++.h>
	#define all(x) (x).begin(),(x).end()
	using namespace std;

	typedef long long ll;
	typedef pair<ll,ll> PII;
	const int N = 2e5 + 10;

	ll nums[60];

	int main(){
		ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
		int T;
		cin >> T;
		//T = 1;
		while(T--){
			ll n,s;
			cin >> n >> s;
			cout << s / n / n << "\n";
		}
		return 0;
	}