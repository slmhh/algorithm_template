#include<stdio.h>

int nums[15],use[15],n;

void dfs(int deep){
    if(deep > n){  //边界判断
        for(int i = 0;i < n;i++)
            printf("%d ",nums[i + 1]);
        printf("\n");
        return ;
    }
    for(int i = 0;i < n;i++){  //枚举1到n
        if(use[i] != 1){
            use[i] = 1;
            nums[deep] = i;
            dfs(deep + 1);
            use[i] = 0;
        }
    }
    return ;
}

int main(){
    scanf("%d",&n);
    dfs(1);
    return 0;
}